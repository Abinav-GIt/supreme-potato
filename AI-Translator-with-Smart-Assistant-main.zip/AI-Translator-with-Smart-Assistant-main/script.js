/* ---------------------------
   🎙️ Translator + 🤖 Chatbot
---------------------------- */

// === TRANSLATOR LOGIC === //
const speechBtn = document.getElementById('speechBtn');
const translateBtn = document.getElementById('translateBtn');
const translatedText = document.getElementById('translatedText');
const audioPlayer = document.getElementById('audioPlayer');
const textInput = document.getElementById('textInput');
const targetLang = document.getElementById('target_language');
const loader = document.getElementById('loader');

let mediaRecorder;
let audioChunks = [];

// 🎤 Speech Translation
speechBtn.onclick = async () => {
  try {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    mediaRecorder = new MediaRecorder(stream);
    audioChunks = [];
    mediaRecorder.start();
    speechBtn.textContent = "⏹ Stop Recording";

    mediaRecorder.ondataavailable = e => audioChunks.push(e.data);

    mediaRecorder.onstop = sendAudioToServer;

    setTimeout(() => {
      if (mediaRecorder.state === "recording") {
        mediaRecorder.stop();
        speechBtn.textContent = "🎙 Speak English";
      }
    }, 5000);

    mediaRecorder.onstop = () => {
      speechBtn.textContent = "🎙 Speak English";
      sendAudioToServer();
    };
  } catch (err) {
    alert("Microphone access denied or unavailable.");
    console.error(err);
  }
};

// 📨 Send recorded audio to backend
async function sendAudioToServer() {
  const blob = new Blob(audioChunks, { type: 'audio/wav' });
  const formData = new FormData();
  formData.append('mode', 'speech');
  formData.append('audio', blob, 'speech.wav');
  formData.append('target_language', targetLang.value);

  showLoader(true);
  const response = await fetch('/translate', { method: 'POST', body: formData });
  const data = await response.json();

  showLoader(false);
  translatedText.textContent = data.translated_text;
  audioPlayer.src = data.audio_url;
}

// 📝 Text Translation
translateBtn.onclick = async () => {
  const text = textInput.value.trim();
  if (!text) return alert("Please enter text!");

  const formData = new FormData();
  formData.append('mode', 'text');
  formData.append('text', text);
  formData.append('target_language', targetLang.value);

  showLoader(true);
  const response = await fetch('/translate', { method: 'POST', body: formData });
  const data = await response.json();

  showLoader(false);
  translatedText.textContent = data.translated_text;
  audioPlayer.src = data.audio_url;
};

// Loader control
function showLoader(isVisible) {
  loader.classList.toggle('hidden', !isVisible);
}

// Toggle Chat Box visibility
document.getElementById("chat-toggle").addEventListener("click", () => {
  document.getElementById("chat-box").classList.toggle("hidden");
});

// Handle AI chat message sending
const chatBtn = document.getElementById("sendChatBtn");
const chatInput = document.getElementById("chatMessage");
const chatWindow = document.getElementById("chat-window");

async function sendChat() {
  const message = chatInput.value.trim();
  if (!message) return;

  // Display user message
  const userMsg = document.createElement("div");
  userMsg.className = "user-msg";
  userMsg.innerText = message;
  chatWindow.appendChild(userMsg);

  chatInput.value = "";

  // Call backend Gemini AI
  const response = await fetch("/chat", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ message })
  });
  
  const data = await response.json();
  const aiMsg = document.createElement("div");
  aiMsg.className = "ai-msg";
  aiMsg.innerText = data.reply || "⚠️ Error connecting to AI.";
  chatWindow.appendChild(aiMsg);
  chatWindow.scrollTop = chatWindow.scrollHeight;
}

chatBtn.addEventListener("click", sendChat);
chatInput.addEventListener("keypress", e => {
  if (e.key === "Enter") sendChat();
});


